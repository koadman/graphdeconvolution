#!/usr/bin/perl

use strict;
my @files = <*cov*txt>;
my @covArray = ();
foreach my $file (@files){

    open(FILE, $file) or die "Can't open $file\n";

    while(my $line = <FILE>){
        chomp($line);

        if($line=~/>(.*)/){
            my @tokens = split(/ /,$1);
            my $idx = $tokens[0];
            my $covString = $tokens[-1];

            if ($covString =~ /_cov_(.*)_ID_s(\d+)_(\d)/){
                my $val = $1;
                my $sample = $2;
                my $direction = $3;
                $covArray[$idx][$sample]+=$val;
                #print "$idx,$val,$sample,$direction\n";
            }
        }
    }
    close(FILE);

    #S0_m3_k81_cov_r1.txt:>26 LN:i:161 KC:i:10640 KM:f:131.4 L:-:2:+ L:+:90:+ _cov_5.333333_ID_s0_1
}

my $NS = scalar(@{$covArray[0]});
my $NI = scalar(@covArray);

#print "$NI,$NS\n";

for (my $i=0; $i < $NI; $i++){
    my $cString = join(",",@{$covArray[$i]});

    print "$i,$cString\n";
}


