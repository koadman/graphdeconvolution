#!/bin/bash

for i in `seq 0 15`
do


    ../../../BGreatCalm2/bcalm/tigopsk128 coverage -kmer-size 81 -tigs all_m3_k81.unitigs.fa -reads ../Reads/S${i}_R1.fa -out S${i}_m3_k81_cov_r1.txt -name s${i}_1
    ../../../BGreatCalm2/bcalm/tigopsk128 coverage -kmer-size 81 -tigs all_m3_k81.unitigs.fa -reads ../Reads/S${i}_R2.fa -out S${i}_m3_k81_cov_r2.txt -name s${i}_2
done

